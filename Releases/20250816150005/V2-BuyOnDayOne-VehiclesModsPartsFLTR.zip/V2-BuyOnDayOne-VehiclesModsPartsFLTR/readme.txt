Buy On Day One - Vehicles, Mods and Parts lets you buy all vanilla vehicles, vehicle mods and vehicle parts from each trader starting on your first day in the zombie apocalypse. 

Important Notes 
1. If you install Buy On Day One modlets in an existing world, you must reset the trader's inventory using console commands or wait for the trader to reset according to his normal schedule.
2. Not tested in multiplayer.
3. Removing the mod is probably safe, but you probably should reset the trader's inventory using console commands or wait for the trader to reset according to his normal schedule.
